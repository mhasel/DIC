// main.c, Haselberger Michael
// Description: LED Dot Matrix
#include "project.h"
#include <stdint.h>
#include "cypins.h"

static const uint16_t delay_ms = 500U;

#define COL(__INDEX__, __LEVEL__) (Pin_Col(__INDEX__)_Write(__LEVEL__))

typedef enum
{
    LOW = 0,
    HIGH
} level;

static uint8_t left_right(void);
static uint8_t up_down(void);
static void SetColumns(level level);
static void SetRows(level level);


int main(void)
{
    
    CyGlobalIntEnable;
    
    while(1)
    {
        left_right();
        up_down();
    }
}

static uint8_t left_right(void)
{
    COL(1, HIGH);
    // reset all LEDS
    SetColumns(LOW);
    SetRows(LOW);
    for (int col = 1; col <= 8; ++col)
    {
        switch(col)
        {
            case 1:
                Pin_Col1_Write(0);
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                break;
            case 6:
                break;
            case 7:
                break;
            case 8:
                break;
        }
    }
    
    return 0;
}

static uint8_t up_down(void)
{
    return 0;
}

static void SetColumns(level level)
{
    // invert logic
    level = level ? LOW : HIGH;
    
    Pin_Col1_Write(level);
    Pin_Col2_Write(level);
    Pin_Col3_Write(level);
    Pin_Col4_Write(level);
    Pin_Col5_Write(level);
    Pin_Col6_Write(level);
    Pin_Col7_Write(level);
    Pin_Col8_Write(level);
}

static void SetRows(level level)
{
    Pin_Row1_Write(0);
    Pin_Row2_Write(0);
    Pin_Row3_Write(0);
    Pin_Row4_Write(0);
    Pin_Row5_Write(0);
    Pin_Row6_Write(0);
    Pin_Row7_Write(0);
    Pin_Row8_Write(0);
}


